<!DOCTYPE html>
<html lang="zxx">


<!-- Mirrored from www.designesia.com/themes/bolo/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 06 Nov 2020 07:00:06 GMT -->
<head>
    <meta charset="utf-8">
   <title> Codeignitersir - One Page Creative Website Template</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Codeignitersir is creative one page website template">
    <meta name="author" content="">

    <!--[if lt IE 9]>
	<script src="js/html5shiv.js"></script>
	<![endif]-->

    <!-- CSS Files
    ================================================== -->
    <link rel="stylesheet" href="<?=base_url('include/css/bootstrap.min.css');?>" type="text/css">
    <link rel="stylesheet" href="<?=base_url('include/css/bootstrap-grid.min.css" type="text/css');?>">
    <link rel="stylesheet" href="<?=base_url('include/css/bootstrap-reboot.min.css" type="text/css');?>">
    <link rel="stylesheet" href="<?=base_url('include/css/animate.css" type="text/css');?>">
    <link rel="stylesheet" href="<?=base_url('include/css/owl.carousel.css" type="text/css');?>">
    <link rel="stylesheet" href="<?=base_url('include/css/owl.theme.css" type="text/css');?>">
    <link rel="stylesheet" href="<?=base_url('include/css/owl.transitions.css" type="text/css');?>">
    <link rel="stylesheet" href="<?=base_url('include/css/magnific-popup.css" type="text/css');?>">
    <link rel="stylesheet" href="<?=base_url('include/css/jquery.countdown.css" type="text/css');?>">
    <link rel="stylesheet" href="<?=base_url('include/css/style.css" type="text/css');?>">
    <link rel="stylesheet" href="<?=base_url('include/css/colors/red.css" type="text/css');?>">
    

</head>

<body>

    <div id="wrapper">

        <div class="page-overlay">
            <div class="preloader-wrap">
                <div class="spinner">
                    <div class="bounce1"></div>
                    <div class="bounce2"></div>
                    <div class="bounce3"></div>
                </div>
            </div>
        </div>

        <!-- header begin -->
        <?php include "header.php";?>

        <!-- header close -->

        <!-- content begin -->
        <div id="content" class="no-bottom no-top">
            <div id="top"></div>

            <!-- section begin -->
            <section id="section-intro" class="full-height relative owl-slide-wrapper text-light no-top no-bottom" data-bgimage="url(images/background/5.jpg)" data-stellar-background-ratio=".2">
                <div class="overlay-bg t50">

                    <div class="center-y relative">
                        <div class="container">
                            <div class="row">
                                <div class="col-md-8">
                                    <div class="spacer-double d-block d-sm-none d-md-block"></div>
									<h3>Awards Winning</h3>
                                    <h1 class="big b">Creative Advertising <span class="id-color">&amp;</span> Branding Agency</h1>
                                    <div class="spacer-single"></div>
                                    <a href="https://themeforest.net/item/Codeignitersir-onepage-creative-website-template/25030305" class="btn-custom">Buy Codeignitersir Now</a>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>

                <a href="#section-services" class="scroll-to">
                    <span class="mouse">
						 <span class="scroll"></span>
                    </span>
                </a>
            </section>
            <!-- section close -->

            <!-- section begin -->
            <section id="section-services">
                <div class="container">

                    <div class="row align-items-center">
						<div class="col-md-8">
							<div class="row sequence">
								<!-- feature box begin -->
								<div class="col-md-6 mb40 sq-item wow sq-item wow">
									<div class="feature-box style-2 left">
										<i class="icon-pencil"></i>
										<div class="text">
											<h3>Website Design</h3>
											Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem.
										</div>
									</div>
								</div>
								<!-- feature box close -->

								<!-- feature box begin -->
								<div class="col-md-6 feature-box mb40 sq-item wow">
									<div class="feature-box style-2 left">
										<i class="icon-envelope"></i>
										<div class="text">
											<h3>Marketing</h3>
											Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem.
										</div>
									</div>
								</div>
								<!-- feature box close -->

								<!-- feature box begin -->
								<div class="col-md-6 feature-box sm-mb40 sq-item wow">
									<div class="feature-box style-2 left">
										<i class="icon-pricetags"></i>
										<div class="text">
											<h3>Branding</h3>
											Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem.
										</div>
									</div>
								</div>
								<!-- feature box close -->

								<!-- feature box begin -->
								<div class="col-md-6 feature-box sm-mb40 sq-item wow">
									<div class="feature-box style-2 left">
										<i class="icon-tools"></i>
										<div class="text">
											<h3>Development</h3>
											Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem.
										</div>
									</div>
								</div>
								<!-- feature box close -->
							</div>
						</div>
						
						<div class="col-md-4">
							<figure class="picframe invert transparent hover-shadow rounded">
                                    <span class="overlay-v">
										<span class="v-center">
											<span>
												<a id="play-video" class="video-play-button popup-youtube" href="https://www.youtube.com/watch?v=CmCIZ_aUAeQ">
													<span></span>
												</a>
											</span>
										</span>
									</span>
                                <img src="<?php echo base_url();?>include/images/misc/2.jpg" class="img-fullwidth" alt="">
                            </figure>
						</div>
					</div>
					
                </div>
            </section>
            <!-- section close -->
			
			<!-- section begin -->
            <section class="bg-color text-light pt60 pb60">
                <div class="container">

                    <div class="row">
                        <div class="col-md-3 col-sm-6 col-xs-6 mb-sm-30">
                            <div class="de_count">
                                <h3 class="timer" data-to="8240" data-speed="2500">0</h3>
                                <span>Hours of Works</span>
                            </div>
                        </div>

                        <div class="col-md-3 col-sm-6 col-xs-6 mb-sm-30">
                            <div class="de_count">
                                <h3 class="timer" data-to="315">0</h3>
                                <span>Projects Done</span>
                            </div>
                        </div>

                        <div class="col-md-3 col-sm-6 col-xs-6 mb-sm-30">
                            <div class="de_count">
                                <h3 class="timer" data-to="250">0</h3>
                                <span>Satisfied Customers</span>
                            </div>
                        </div>

                        <div class="col-md-3 col-sm-6 col-xs-6 mb-sm-30">
                            <div class="de_count">
                                <h3 class="timer" data-to="32" data-speed="2500">0</h3>
                                <span>Awards Winning</span>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!-- section close -->

            <!-- section begin -->
            <section data-bgcolor="#f9f9f9">
                <div class="container">
                    <div class="row align-items-center">

                        <div class="col-md-6">
                            <img src="<?php echo base_url();?>include/images/misc/laptop.png" class="mb-sm-30 img-fluid" alt="">
                        </div>

                        <div class="col-md-5 offset-md-1">
                            <h2 class="mb20">Codeignitersir do creative works. We ready to help you.</h2>
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
                            <div class="spacer-half"></div>
                            <a href="#section-portfolio" class="btn-custom scroll-to">See Our Works</a>
                        </div>

                        <div class="clearfix"></div>
                    </div>
                </div>
            </section>
            <!-- section close -->

            <!-- section begin -->
            <section id="section-portfolio" aria-label="section-portfolio" class="no-top no-bottom" data-bgcolor="#fafafa">
                <div class="container-fluid">
                    <div class="row no-gutters gallery-wrap sequence_pf">

                        <!-- gallery item -->
                        <div class="col-lg-4 col-md-6 col-sm-6 sq-item">
                            <div class="picframe wow">
                                <div class="pf-click" data-value="project-details-image.html">
                                    <span class="overlay">
											<span class="title">
												<span>Single Image</span>
                                    </span>
                                    </span>
                                    <img src="<?php echo base_url();?>include/images/portfolio/pf%20(1).jpg" class="wow" alt="" />
                                </div>
                            </div>
                        </div>
                        <!-- close gallery item -->

                        <!-- gallery item -->
                        <div class="col-lg-4 col-md-6 col-sm-6 sq-item">
                            <div class="picframe wow">
                                <div class="pf-click" data-value="project-details-slider.html">
                                    <span class="overlay">
											<span class="title">
												<span>Multi Images Slider</span>
                                    </span>
                                    </span>
                                    <img src="<?php echo base_url();?>include/images/portfolio/pf%20(2).jpg" class="wow" alt="" />
                                </div>
                            </div>
                        </div>
                        <!-- close gallery item -->

                        <!-- gallery item -->
                        <div class="col-lg-4 col-md-6 col-sm-6 sq-item wow">
                            <div class="picframe wow">
                                <div class="pf-click" data-value="project-details-youtube.html">
                                    <span class="overlay">
											<span class="title">
												<span>Youtube Video</span>
                                    </span>
                                    </span>
                                    <img src="<?php echo base_url();?>include/images/portfolio/pf%20(3).jpg" class="wow" alt="" />
                                </div>
                            </div>
                        </div>
                        <!-- close gallery item -->

                        <!-- gallery item -->
                        <div class="col-lg-4 col-md-6 col-sm-6 sq-item">
                            <div class="picframe wow">
                                <div class="pf-click" data-value="project-details-image-big.html">
                                    <span class="overlay">
											<span class="title">
												<span>Single Image Big</span>
                                    </span>
                                    </span>
                                    <img src="<?php echo base_url();?>include/images/portfolio/pf%20(4).jpg" class="wow" alt="" />
                                </div>
                            </div>
                        </div>
                        <!-- close gallery item -->

                        <!-- gallery item -->
                        <div class="col-lg-4 col-md-6 col-sm-6 sq-item">
                            <div class="picframe wow">
                                <div class="pf-click" data-value="project-details-slider-big.html">
                                    <span class="overlay">
											<span class="title">
												<span>Multi Images Slider Big</span>
                                    </span>
                                    </span>
                                    <img src="<?php echo base_url();?>include/images/portfolio/pf%20(5).jpg" class="wow" alt="" />
                                </div>
                            </div>
                        </div>
                        <!-- close gallery item -->

                        <!-- gallery item -->
                        <div class="col-lg-4 col-md-6 col-sm-6 sq-item">
                            <div class="picframe wow">
                                <div class="pf-click" data-value="project-details-youtube-big.html">
                                    <span class="overlay">
											<span class="title">
												<span>Youtube Video Big</span>
                                    </span>
                                    </span>
                                    <img src="<?php echo base_url();?>include/images/portfolio/pf%20(6).jpg" class="wow" alt="" />
                                </div>
                            </div>
                        </div>
                        <!-- close gallery item -->

                    </div>
                </div>
            </section>
            <!-- section close -->

            <div id="loader-area">
                <div class="container">
                    <div class="project-load"></div>
                </div>
            </div>

            <!-- section begin -->
            <section id="section-blog" data-bgcolor="#f9f9f9">
                <div class="container">
                    <div class="row">

                        <div class="col-md-12">
                            <div id="blog-carousel" class="owl-carousel owl-theme">
                                <div class="post-item s1 item">
                                    <div class="date-box">
                                        <div class="m">10</div>
                                        <div class="d">JUN</div>
                                    </div>

                                    <div class="post-content">
                                        <div class="post-text">
                                            <h3><a href="#">Make Better User Interface</a></h3>
                                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
                                        </div>
                                    </div>
                                </div>

                                <div class="post-item s1 item">
                                    <div class="post-content">
                                        <div class="date-box">
                                            <div class="m">15</div>
                                            <div class="d">JUN</div>
                                        </div>

                                        <div class="post-text">
                                            <h3><a href="#">Experts Web Design Tips</a></h3>
                                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
                                        </div>
                                    </div>
                                </div>

                                <div class="post-item s1 item">
                                    <div class="post-content">
                                        <div class="date-box">
                                            <div class="m">20</div>
                                            <div class="d">JUN</div>
                                        </div>

                                        <div class="post-text">
                                            <h3><a href="#">Importance Of Web Design</a></h3>
                                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
                                        </div>


                                    </div>
                                </div>

                                <div class="post-item s1 item">
                                    <div class="post-content">
                                        <div class="date-box">
                                            <div class="m">22</div>
                                            <div class="d">JUN</div>
                                        </div>

                                        <div class="post-text">
                                            <h3><a href="#">Avoid Erros In UI Design</a></h3>
                                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
                                        </div>
                                    </div>
                                </div>

                                <div class="post-item s1 item">
                                    <div class="post-content">
                                        <div class="date-box">
                                            <div class="m">28</div>
                                            <div class="d">JUN</div>
                                        </div>

                                        <div class="post-text">
                                            <h3><a href="#">Make Your Website Faster</a></h3>
                                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
                                        </div>
                                    </div>
                                </div>

                                <div class="post-item s1 item">
                                    <div class="post-content">
                                        <div class="date-box">
                                            <div class="m">30</div>
                                            <div class="d">JUN</div>
                                        </div>

                                        <div class="post-text">
                                            <h3><a href="#">Create Marketing Website</a></h3>
                                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
                                        </div>


                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </section>
            <!-- section close -->

            </div>
            <!-- content close -->

            <!-- footer begin -->

             <?php include "footer.php";?>
            
            <!-- footer close -->

            <a href="#" id="back-to-top"></a>

            <div id="preloader">
                <div class="preloader1"></div>
            </div>

        </div>

        <!-- Javascript Files
    ================================================== -->
   <script src="<?=base_url('include/js/jquery.min.js');?>"></script>
        <script src="<?=base_url('include/js/bootstrap.min.js');?>"></script>
        <script src="<?=base_url('include/js/jquery.isotope.min.js');?>"></script>
        <script src="<?=base_url('include/js/easing.js');?>"></script>
        <script src="<?=base_url('include/js/owl.carousel.js');?>"></script>
        <script src="<?=base_url('include/js/jquery.countTo.js');?>"></script>
        <script src="<?=base_url('include/js/wow.min.js');?>"></script>
        <script src="<?=base_url('include/js/jquery.magnific-popup.min.js');?>"></script>
        <script src="<?=base_url('include/js/enquire.min.js');?>"></script>
        <script src="<?=base_url('include/js/jquery.stellar.min.js');?>"></script>
        <script src="<?=base_url('include/js/jquery.plugin.js');?>"></script>     
        <script src="<?=base_url('include/js/jquery.easeScroll.js');?>"></script>
        <script src="<?=base_url('include/js/designesia.js');?>"></script>
        <script src="<?=base_url('include/js/validation.js');?>"></script>
        
</body>


<!-- Mirrored from www.designesia.com/themes/bolo/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 06 Nov 2020 07:00:14 GMT -->
</html>