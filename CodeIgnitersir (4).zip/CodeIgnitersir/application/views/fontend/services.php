

        <!DOCTYPE html>
<html lang="zxx">


<!-- Mirrored from www.designesia.com/themes/bolo/services.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 06 Nov 2020 07:04:17 GMT -->
<head>
    <meta charset="utf-8">
    <title>Codeignitersir - One Page Creative Website Template</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Codeignitersir is creative one page website template">
    <meta name="author" content="">

    <!--[if lt IE 9]>
    <script src="js/html5shiv.js"></script>
    <![endif]-->

    <!-- CSS Files
    ================================================== -->
    <link rel="stylesheet" href="<?=base_url('include/css/bootstrap.min.css');?>" type="text/css">
    <link rel="stylesheet" href="<?=base_url('include/css/bootstrap-grid.min.css" type="text/css');?>">
    <link rel="stylesheet" href="<?=base_url('include/css/bootstrap-reboot.min.css" type="text/css');?>">
    <link rel="stylesheet" href="<?=base_url('include/css/animate.css" type="text/css');?>">
    <link rel="stylesheet" href="<?=base_url('include/css/owl.carousel.css" type="text/css');?>">
    <link rel="stylesheet" href="<?=base_url('include/css/owl.theme.css" type="text/css');?>">
    <link rel="stylesheet" href="<?=base_url('include/css/owl.transitions.css" type="text/css');?>">
    <link rel="stylesheet" href="<?=base_url('include/css/magnific-popup.css" type="text/css');?>">
    <link rel="stylesheet" href="<?=base_url('include/css/jquery.countdown.css" type="text/css');?>">
    <link rel="stylesheet" href="<?=base_url('include/css/style.css" type="text/css');?>">
    <link rel="stylesheet" href="<?=base_url('include/css/colors/red.css" type="text/css');?>">
</head>

<body>

    <div id="wrapper">

        <div class="page-overlay">
            <div class="preloader-wrap">
                <div class="spinner">
                    <div class="bounce1"></div>
                    <div class="bounce2"></div>
                    <div class="bounce3"></div>
                </div>
            </div>
        </div>

        <!-- header close -->
<?php include "header.php";?>


        <!-- content begin -->
        <div id="content" class="no-bottom no-top">
            <div id="top"></div>

            <!-- section begin -->
            <section id="subheader" class="text-light" data-bgimage="url(images/background/12.jpg)" data-stellar-background-ratio=".2">
                <div class="overlay-bg t50">
                
                    <div class="container">
                        <div class="row">
                            <div class="col-md-12">
                                <h1>Our Services</h1>
                                <p>Codeignitersir do creative works</p>
                            </div>
                        </div>
                    </div>
                    
                </div>
                
            </section>
            <!-- section close -->
            
            <!-- section begin -->
            <section id="section-services">
                <div class="container">

                    <div class="row sequence">
                        <!-- feature box begin -->
                        <div class="col-md-4 col-sm-6 mb40 sq-item wow sq-item wow">
                            <div class="feature-box style-2 left">
                                <i class="icon-pencil"></i>
                                <div class="text">
                                    <h3>Website Design</h3>
                                    Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem.
                                </div>
                            </div>
                        </div>
                        <!-- feature box close -->

                        <!-- feature box begin -->
                        <div class="col-md-4 col-sm-6 mb40 sq-item wow">
                            <div class="feature-box style-2 left">
                                <i class="icon-envelope"></i>
                                <div class="text">
                                    <h3>Marketing</h3>
                                    Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem.
                                </div>
                            </div>
                        </div>
                        <!-- feature box close -->

                        <!-- feature box begin -->
                        <div class="col-md-4 col-sm-6 mb40 sq-item wow">
                            <div class="feature-box style-2 left">
                                <i class="icon-camera"></i>
                                <div class="text">
                                    <h3>Photography</h3>
                                    Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem.
                                </div>
                            </div>
                        </div>
                        <!-- feature box close -->

                        <!-- feature box begin -->
                        <div class="col-md-4 col-sm-6 sm-mb40 sq-item wow">
                            <div class="feature-box style-2 left">
                                <i class="icon-pricetags"></i>
                                <div class="text">
                                    <h3>Branding</h3>
                                    Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem.
                                </div>
                            </div>
                        </div>
                        <!-- feature box close -->

                        <!-- feature box begin -->
                        <div class="col-md-4 col-sm-6 sm-mb40 sq-item wow">
                            <div class="feature-box style-2 left">
                                <i class="icon-tools"></i>
                                <div class="text">
                                    <h3>Development</h3>
                                    Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem.
                                </div>
                            </div>
                        </div>
                        <!-- feature box close -->

                        <!-- feature box begin -->
                        <div class="col-md-4 col-sm-6 sm-mb40 sq-item wow">
                            <div class="feature-box style-2 left">
                                <i class="icon-magnifying-glass"></i>
                                <div class="text">
                                    <h3>Search Engine Optimisation</h3>
                                    Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem.
                                </div>
                            </div>
                        </div>
                        <!-- feature box close -->
                    </div>
                </div>
            </section>
            <!-- section close -->
            
            <!-- section begin -->
            <section id="section-clients" aria-label="section" class="pt60 pb40" data-bgcolor="#f9f9f9">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12 text-center wow fadeInUp">
                            <div class="owl-carousel owl-sponsors gray">
                                <div class="item"><img src="<?php echo base_url('include/images/logo/1.png');?>" alt=""></div>
                                <div class="item"><img src="<?php echo base_url('include/images/logo/2.png');?>" alt=""></div>
                                <div class="item"><img src="<?php echo base_url('include/images/logo/3.png');?>" alt=""></div>
                                <div class="item"><img src="<?php echo base_url('include/images/logo/4.png');?>" alt=""></div>
                                <div class="item"><img src="<?php echo base_url('include/images/logo/5.png');?>" alt=""></div>
                                <div class="item"><img src="<?php echo base_url('include/images/logo/6.png');?>" alt=""></div>
                                <div class="item"><img src="<?php echo base_url('include/images/logo/7.png');?>" alt=""></div>
                                <div class="item"><img src="<?php echo base_url('include/images/logo/8.png');?>" alt=""></div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!-- section close -->

            </div>
            <!-- content close -->

            <!-- footer begin -->
            <?php include "footer.php";?>
            <!-- <footer>
                <div class="container">
                    <div class="row">
                        <div class="col-md-6 sm-mb10">
                            <div class="mt10">&copy; Copyright 2020 - Bolo by Designesia </div>
                        </div>

                        <div class="col-md-6 text-left text-md-right">
                            <div class="social-icons">
                                <a href="#"><i class="fa fa-facebook fa-lg"></i></a>
                                <a href="#"><i class="fa fa-twitter fa-lg"></i></a>
                                <a href="#"><i class="fa fa-linkedin fa-lg"></i></a>
                                <a href="#"><i class="fa fa-google-plus fa-lg"></i></a>
                                <a href="#"><i class="fa fa-rss fa-lg"></i></a>
                            </div>
                        </div>
                    </div>
                </div>

            </footer> -->
            <!-- footer close -->

            <a href="#" id="back-to-top"></a>

            <div id="preloader">
                <div class="preloader1"></div>
            </div>

        </div>

        <!-- Javascript Files
    ================================================== -->
      <script src="<?=base_url('include/js/jquery.min.js');?>"></script>
        <script src="<?=base_url('include/js/bootstrap.min.js');?>"></script>
        <script src="<?=base_url('include/js/jquery.isotope.min.js');?>"></script>
        <script src="<?=base_url('include/js/easing.js');?>"></script>
        <script src="<?=base_url('include/js/owl.carousel.js');?>"></script>
        <script src="<?=base_url('include/js/jquery.countTo.js');?>"></script>
        <script src="<?=base_url('include/js/wow.min.js');?>"></script>
        <script src="<?=base_url('include/js/jquery.magnific-popup.min.js');?>"></script>
        <script src="<?=base_url('include/js/enquire.min.js');?>"></script>
        <script src="<?=base_url('include/js/jquery.stellar.min.js');?>"></script>
        <script src="<?=base_url('include/js/jquery.plugin.js');?>"></script>     
        <script src="<?=base_url('include/js/jquery.easeScroll.js');?>"></script>
        <script src="<?=base_url('include/js/designesia.js');?>"></script>
        <script src="<?=base_url('include/js/validation.js');?>"></script>
        


<!-- Mirrored from www.designesia.com/themes/bolo/services.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 06 Nov 2020 07:04:17 GMT -->
</html>