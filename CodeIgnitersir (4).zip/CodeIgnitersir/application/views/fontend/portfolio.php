
        <!DOCTYPE html>
<html lang="zxx">


<!-- Mirrored from www.designesia.com/themes/bolo/portfolio.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 06 Nov 2020 07:04:17 GMT -->
<head>
    <meta charset="utf-8">
    <title>Codeignitersir- One Page Creative Website Template</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Codeignitersir is creative one page website template">
    <meta name="author" content="">

    <!--[if lt IE 9]>
    <script src="js/html5shiv.js"></script>
    <![endif]-->

    <!-- CSS Files
    ================================================== -->
    <link rel="stylesheet" href="<?=base_url('include/css/bootstrap.min.css');?>" type="text/css">
    <link rel="stylesheet" href="<?=base_url('include/css/bootstrap-grid.min.css" type="text/css');?>">
    <link rel="stylesheet" href="<?=base_url('include/css/bootstrap-reboot.min.css" type="text/css');?>">
    <link rel="stylesheet" href="<?=base_url('include/css/animate.css" type="text/css');?>">
    <link rel="stylesheet" href="<?=base_url('include/css/owl.carousel.css" type="text/css');?>">
    <link rel="stylesheet" href="<?=base_url('include/css/owl.theme.css" type="text/css');?>">
    <link rel="stylesheet" href="<?=base_url('include/css/owl.transitions.css" type="text/css');?>">
    <link rel="stylesheet" href="<?=base_url('include/css/magnific-popup.css" type="text/css');?>">
    <link rel="stylesheet" href="<?=base_url('include/css/jquery.countdown.css" type="text/css');?>">
    <link rel="stylesheet" href="<?=base_url('include/css/style.css" type="text/css');?>">
    <link rel="stylesheet" href="<?=base_url('include/css/colors/red.css" type="text/css');?>">
</head>

<body>

    <div id="wrapper">

        <div class="page-overlay">
            <div class="preloader-wrap">
                <div class="spinner">
                    <div class="bounce1"></div>
                    <div class="bounce2"></div>
                    <div class="bounce3"></div>
                </div>
            </div>
        </div>

        <!-- header begin -->
        <?php include "header.php";?>
        <!-- header close -->

        <!-- content begin -->
        <div id="content" class="no-bottom no-top">
            <div id="top"></div>
            
            <!-- section begin -->
            <section id="section-portfolio" aria-label="section-portfolio" class="no-top no-bottom">
                <div class="spacer-double d-none d-lg-block"></div>
                <div class="spacer-double d-none d-lg-block"></div>
                
                <div class="container-fluid">
                    <div class="row no-gutters gallery-wrap sequence_pf">

                        <!-- gallery item -->
                        <div class="col-lg-4 col-md-6 col-sm-6 sq-item">
                            <div class="picframe wow">
                                <div class="pf-click" data-value="project-details-image.html">
                                    <span class="overlay">
                                            <span class="title">
                                                <span>Single Image</span>
                                    </span>
                                    </span>
                                    <img src="<?php echo base_url('include/images/portfolio/pf%20(1).jpg');?>" class="wow" alt="" />
                                </div>
                            </div>
                        </div>
                        <!-- close gallery item -->

                        <!-- gallery item -->
                        <div class="col-lg-4 col-md-6 col-sm-6 sq-item">
                            <div class="picframe wow">
                                <div class="pf-click" data-value="project-details-slider.html">
                                    <span class="overlay">
                                            <span class="title">
                                                <span>Multi Images Slider</span>
                                    </span>
                                    </span>
                                    <img src="<?php echo base_url('include/images/portfolio/pf%20(2).jpg');?>" class="wow" alt="" />
                                </div>
                            </div>
                        </div>
                        <!-- close gallery item -->

                        <!-- gallery item -->
                        <div class="col-lg-4 col-md-6 col-sm-6 sq-item wow">
                            <div class="picframe wow">
                                <div class="pf-click" data-value="project-details-youtube.html">
                                    <span class="overlay">
                                            <span class="title">
                                                <span>Youtube Video</span>
                                    </span>
                                    </span>
                                    <img src="<?php echo base_url('include/images/portfolio/pf%20(3).jpg');?>" class="wow" alt="" />
                                </div>
                            </div>
                        </div>
                        <!-- close gallery item -->

                        <!-- gallery item -->
                        <div class="col-lg-4 col-md-6 col-sm-6 sq-item">
                            <div class="picframe wow">
                                <div class="pf-click" data-value="project-details-image-big.html">
                                    <span class="overlay">
                                            <span class="title">
                                                <span>Single Image Big</span>
                                    </span>
                                    </span>
                                    <img src="<?php echo base_url('include/images/portfolio/pf%20(4).jpg');?>" class="wow" alt="" />
                                </div>
                            </div>
                        </div>
                        <!-- close gallery item -->

                        <!-- gallery item -->
                        <div class="col-lg-4 col-md-6 col-sm-6 sq-item">
                            <div class="picframe wow">
                                <div class="pf-click" data-value="project-details-slider-big.html">
                                    <span class="overlay">
                                            <span class="title">
                                                <span>Multi Images Slider Big</span>
                                    </span>
                                    </span>
                                    <img src="<?php echo base_url('include/images/portfolio/pf%20(5).jpg');?>" class="wow" alt="" />
                                </div>
                            </div>
                        </div>
                        <!-- close gallery item -->

                        <!-- gallery item -->
                        <div class="col-lg-4 col-md-6 col-sm-6 sq-item">
                            <div class="picframe wow">
                                <div class="pf-click" data-value="project-details-youtube-big.html">
                                    <span class="overlay">
                                            <span class="title">
                                                <span>Youtube Video Big</span>
                                    </span>
                                    </span>
                                    <img src="<?php echo base_url('include/images/portfolio/pf%20(6).jpg');?>" class="wow" alt="" />
                                </div>
                            </div>
                        </div>
                        <!-- close gallery item -->

                    </div>
                </div>
            </section>
            <!-- section close -->

            <div id="loader-area" data-bgcolor="#fafafa">
                <div class="container">
                    <div class="project-load"></div>
                </div>
            </div>

            </div>
            <!-- content close -->

            <!-- footer begin -->
            
            <?php include "footer.php";?>
            <!-- footer close -->

            <a href="#" id="back-to-top"></a>

            <div id="preloader">
                <div class="preloader1"></div>
            </div>

        </div>

        <!-- Javascript Files
    ================================================== -->
       <script src="<?=base_url('include/js/jquery.min.js');?>"></script>
        <script src="<?=base_url('include/js/bootstrap.min.js');?>"></script>
        <script src="<?=base_url('include/js/jquery.isotope.min.js');?>"></script>
        <script src="<?=base_url('include/js/easing.js');?>"></script>
        <script src="<?=base_url('include/js/owl.carousel.js');?>"></script>
        <script src="<?=base_url('include/js/jquery.countTo.js');?>"></script>
        <script src="<?=base_url('include/js/wow.min.js');?>"></script>
        <script src="<?=base_url('include/js/jquery.magnific-popup.min.js');?>"></script>
        <script src="<?=base_url('include/js/enquire.min.js');?>"></script>
        <script src="<?=base_url('include/js/jquery.stellar.min.js');?>"></script>
        <script src="<?=base_url('include/js/jquery.plugin.js');?>"></script>     
        <script src="<?=base_url('include/js/jquery.easeScroll.js');?>"></script>
        <script src="<?=base_url('include/js/designesia.js');?>"></script>
        <script src="<?=base_url('include/js/validation.js');?>"></script>
        

</body>


<!-- Mirrored from www.designesia.com/themes/bolo/portfolio.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 06 Nov 2020 07:04:17 GMT -->
</html>
        