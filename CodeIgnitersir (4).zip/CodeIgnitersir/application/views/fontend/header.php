<header>

            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <!-- logo begin -->
                        <div id="logo">
                            <a href="index.html">
                                <img class="logo" src="<?php echo base_url('include/images/logo-light.png');?>" alt="">
                                <img class="logo-2" src="<?php echo base_url('include/images/logo-dark.png');?>" alt="">
                            </a>
                        </div>
                        <!-- logo close -->

                        <!-- small button begin -->
                        <span id="menu-btn"></span>
                        <!-- small button close -->

                        <!-- mainmenu begin -->
                        <nav>
                            <ul id="mainmenu">
                                <li><a href="index.html">Home</a>
									<ul class="mega">
										<li>
											<div class="container">
												<div class="menu-content">
													<div class="row">
														<div class="col-md-3 mb-lg-4 mb-sm-0">
															<a href="index-onepage-10.html" class="no-padding">
																<img src="images/preview/12.jpg" class="img-fullwidth" alt="">
															</a>
														</div>
														
														<div class="col-md-3 mb-lg-4 mb-sm-0">
															<a href="index.html" class="no-padding">
																<img src="images/preview/9.jpg" class="img-fullwidth" alt="">
															</a>
														</div>
														
														<div class="col-md-3 hidden-sm">
															<a href="index-onepage-7.html" class="no-padding">
																<img src="images/preview/7.jpg" class="img-fullwidth" alt="">
															</a>
														</div>
														
														<div class="col-md-3 hidden-sm">
															<a href="index-onepage-6.html" class="no-padding">
																<img src="images/preview/6.jpg" class="img-fullwidth" alt="">
															</a>
														</div>
														
														<div class="col-md-3 hidden-sm">
															<a href="index-onepage-8.html" class="no-padding">
																<img src="images/preview/8.jpg" class="img-fullwidth" alt="">
															</a>
														</div>
														
														<div class="col-md-3 hidden-sm">
															<a href="index-business.html" class="no-padding">
																<img src="images/preview/10.jpg" class="img-fullwidth" alt="">
															</a>
														</div>
														
														<div class="col-md-3 mb-lg-4 mb-sm-0">
															<a href="index-onepage-9.html" class="no-padding">
																<img src="images/preview/11.jpg" class="img-fullwidth" alt="">
															</a>
														</div>
														
														<div class="col-md-3 mb-lg-4 mb-sm-0">
															<a href="index-onepage-1.html" class="no-padding">
																<img src="images/preview/1.jpg" class="img-fullwidth" alt="">
															</a>
														</div>
														
														<div class="col-md-3 mb-lg-4 mb-sm-0">
															<a href="index-onepage-2.html" class="no-padding">
																<img src="images/preview/2.jpg" class="img-fullwidth" alt="">
															</a>
														</div>
														
														<div class="col-md-3 mb-lg-4 mb-sm-0">
															<a href="index-onepage-3.html" class="no-padding">
																<img src="images/preview/3.jpg" class="img-fullwidth" alt="">
															</a>
														</div>
														
														<div class="col-md-3 mb-lg-4 mb-sm-0">
															<a href="index-onepage-4.html" class="no-padding">
																<img src="images/preview/4.jpg" class="img-fullwidth" alt="">
															</a>
														</div>
														
														<div class="col-md-3 hidden-sm">
															<a href="index-onepage-5.html" class="no-padding">
																<img src="images/preview/5.jpg" class="img-fullwidth" alt="">
															</a>
														</div>
														
														<div class="clearfix"></div>
													</div>
												</div>
											</div>
										</li>                                        
                                    </ul>
								</li>
								<li><a href="<?=base_url('/index.php/welcome/about');?>">About Us</a></li>
                                <li><a href="<?=base_url('/index.php/welcome/services');?>">Services</a></li>
                                <li><a href="<?=base_url('/index.php/welcome/portfolio');?>">Portfolio</a></li>
                                <li><a href="<?=base_url('/index.php/welcome/blog');?>">Blog</a></li>
                                <li><a href="<?=base_url('/index.php/welcome/contact/');?>">Contact</a></li>
                            </ul>
                        </nav>
						<!-- mainmenu close -->

                    </div>

                </div>
            </div>
        </header>