 <!DOCTYPE html>
<html lang="zxx">


<!-- Mirrored from www.designesia.com/themes/bolo/blog.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 06 Nov 2020 07:04:17 GMT -->
<head>
    <meta charset="utf-8">
    <title>Codeignitersir - One Page Creative Website Template</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Codeignitersir is creative one page website template">
    <meta name="author" content="">

    <!--[if lt IE 9]>
    <script src="js/html5shiv.js"></script>
    <![endif]-->

    <!-- CSS Files
    ================================================== -->
    <link rel="stylesheet" href="<?=base_url('include/css/bootstrap.min.css');?>" type="text/css">
    <link rel="stylesheet" href="<?=base_url('include/css/bootstrap-grid.min.css" type="text/css');?>">
    <link rel="stylesheet" href="<?=base_url('include/css/bootstrap-reboot.min.css" type="text/css');?>">
    <link rel="stylesheet" href="<?=base_url('include/css/animate.css" type="text/css');?>">
    <link rel="stylesheet" href="<?=base_url('include/css/owl.carousel.css" type="text/css');?>">
    <link rel="stylesheet" href="<?=base_url('include/css/owl.theme.css" type="text/css');?>">
    <link rel="stylesheet" href="<?=base_url('include/css/owl.transitions.css" type="text/css');?>">
    <link rel="stylesheet" href="<?=base_url('include/css/magnific-popup.css" type="text/css');?>">
    <link rel="stylesheet" href="<?=base_url('include/css/jquery.countdown.css" type="text/css');?>">
    <link rel="stylesheet" href="<?=base_url('include/css/style.css" type="text/css');?>">
    <link rel="stylesheet" href="<?=base_url('include/css/colors/red.css" type="text/css');?>">
</head>

<body>

    <div id="wrapper">

        <div class="page-overlay">
            <div class="preloader-wrap">
                <div class="spinner">
                    <div class="bounce1"></div>
                    <div class="bounce2"></div>
                    <div class="bounce3"></div>
                </div>
            </div>
        </div>

        <!-- header begin -->
        <?php include "header.php";?>
        <!-- header close -->

        <!-- content begin -->
        <div id="content" class="no-bottom no-top">
            <div id="top"></div>

            <!-- section begin -->
            <section id="subheader" class="text-light" data-bgimage="url(images/background/13.jpg)" data-stellar-background-ratio=".2">
                <div class="overlay-bg t50">

                    <div class="container">
                        <div class="row">
                            <div class="col-md-12">
                                <h1>Our Blog</h1>
                                <p>Latest update from the company</p>
                            </div>
                        </div>
                    </div>

                </div>

            </section>
            <!-- section close -->

            <!-- section begin -->
            <section id="section-services" data-bgcolor="#f9f9f9">
                <div class="container">

                    <div class="row">
                        <div class="col-md-4 mb30">
                            <div class="picframe wow mb20">
                                <a href="#">
                                    <span class="overlay">
                                        <span class="title">
                                            <span>Read this article</span>
                                        </span>
                                    </span>
                                    <img src="<?php echo base_url('include/images/blog/1.jpg');?>" class="wow" alt="" />
                                </a>
                            </div>

                            <div class="post-item s1 item">
                                <div class="date-box">
                                    <div class="m">10</div>
                                    <div class="d">JUN</div>
                                </div>

                                <div class="post-content">
                                    <div class="post-text">
                                        <h3><a href="#">Make Better User Interface</a></h3>
                                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna.</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-md-4 mb30">
                            <div class="picframe wow mb20">
                                <a href="#">
                                    <span class="overlay">
                                        <span class="title">
                                            <span>Read this article</span>
                                        </span>
                                    </span>
                                    <img src="<?php echo base_url('include/images/blog/2.jpg');?>" class="wow" alt="" />
                                </a>
                            </div>

                            <div class="post-item s1 item">
                                <div class="date-box">
                                    <div class="m">15</div>
                                    <div class="d">JUN</div>
                                </div>

                                <div class="post-content">
                                    <div class="post-text">
                                        <h3><a href="#">Make Better User Interface</a></h3>
                                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna.</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-md-4 mb30">
                            <div class="picframe wow mb20">
                                <a href="#">
                                    <span class="overlay">
                                        <span class="title">
                                            <span>Read this article</span>
                                        </span>
                                    </span>
                                    <img src="<?php echo base_url('include/images/blog/3.jpg');?>" class="wow" alt="" />
                                </a>
                            </div>

                            <div class="post-item s1 item">
                                <div class="date-box">
                                    <div class="m">20</div>
                                    <div class="d">JUN</div>
                                </div>

                                <div class="post-content">
                                    <div class="post-text">
                                        <h3><a href="#">Make Better User Interface</a></h3>
                                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna.</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-md-4 mb30">
                            <div class="picframe wow mb20">
                                <a href="#">
                                    <span class="overlay">
                                        <span class="title">
                                            <span>Read this article</span>
                                        </span>
                                    </span>
                                    <img src="<?php echo base_url('include/images/blog/4.jpg');?>" class="wow" alt="" />
                                </a>
                            </div>

                            <div class="post-item s1 item">
                                <div class="date-box">
                                    <div class="m">22</div>
                                    <div class="d">JUN</div>
                                </div>

                                <div class="post-content">
                                    <div class="post-text">
                                        <h3><a href="#">Make Better User Interface</a></h3>
                                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna.</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-md-4 mb30">
                            <div class="picframe wow mb20">
                                <a href="#">
                                    <span class="overlay">
                                        <span class="title">
                                            <span>Read this article</span>
                                        </span>
                                    </span>
                                    <img src="<?php echo base_url('include/images/blog/5.jpg');?>" class="wow" alt="" />
                                </a>
                            </div>

                            <div class="post-item s1 item">
                                <div class="date-box">
                                    <div class="m">28</div>
                                    <div class="d">JUN</div>
                                </div>

                                <div class="post-content">
                                    <div class="post-text">
                                        <h3><a href="#">Make Better User Interface</a></h3>
                                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna.</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-md-4 mb30">
                            <div class="picframe wow mb20">
                                <a href="#">
                                    <span class="overlay">
                                        <span class="title">
                                            <span>Read this article</span>
                                        </span>
                                    </span>
                                    <img src="<?php echo base_url('include/images/blog/6.jpg');?>" class="wow" alt="" />
                                </a>
                            </div>

                            <div class="post-item s1 item">
                                <div class="date-box">
                                    <div class="m">30</div>
                                    <div class="d">JUN</div>
                                </div>

                                <div class="post-content">
                                    <div class="post-text">
                                        <h3><a href="#">Make Better User Interface</a></h3>
                                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna.</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </section>
            <!-- section close -->

        </div>
        <!-- content close -->

        <!-- footer begin -->
        <?php include "footer.php";?>
        <!-- footer close -->

        <a href="#" id="back-to-top"></a>

        <div id="preloader">
            <div class="preloader1"></div>
        </div>

    </div>

    <!-- Javascript Files
    ================================================== -->
    <script src="<?=base_url('include/js/jquery.min.js');?>"></script>
        <script src="<?=base_url('include/js/bootstrap.min.js');?>"></script>
        <script src="<?=base_url('include/js/jquery.isotope.min.js');?>"></script>
        <script src="<?=base_url('include/js/easing.js');?>"></script>
        <script src="<?=base_url('include/js/owl.carousel.js');?>"></script>
        <script src="<?=base_url('include/js/jquery.countTo.js');?>"></script>
        <script src="<?=base_url('include/js/wow.min.js');?>"></script>
        <script src="<?=base_url('include/js/jquery.magnific-popup.min.js');?>"></script>
        <script src="<?=base_url('include/js/enquire.min.js');?>"></script>
        <script src="<?=base_url('include/js/jquery.stellar.min.js');?>"></script>
        <script src="<?=base_url('include/js/jquery.plugin.js');?>"></script>     
        <script src="<?=base_url('include/js/jquery.easeScroll.js');?>"></script>
        <script src="<?=base_url('include/js/designesia.js');?>"></script>
        <script src="<?=base_url('include/js/validation.js');?>"></script>
        


</body>


<!-- Mirrored from www.designesia.com/themes/bolo/blog.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 06 Nov 2020 07:05:03 GMT -->
</html>