!DOCTYPE html>
<html lang="zxx">


<!-- Mirrored from www.designesia.com/themes/bolo/contact.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 06 Nov 2020 07:05:03 GMT -->
<head>
    <meta charset="utf-8">
    <title>Codeignitersir - One Page Creative Website Template</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Codeignitersir is creative one page website template">
    <meta name="author" content="">

    <!--[if lt IE 9]>
    <script src="js/html5shiv.js"></script>
    <![endif]-->

    <!-- CSS Files
    ================================================== -->
    <link rel="stylesheet" href="<?=base_url('include/css/bootstrap.min.css');?>" type="text/css">
    <link rel="stylesheet" href="<?=base_url('include/css/bootstrap-grid.min.css" type="text/css');?>">
    <link rel="stylesheet" href="<?=base_url('include/css/bootstrap-reboot.min.css" type="text/css');?>">
    <link rel="stylesheet" href="<?=base_url('include/css/animate.css" type="text/css');?>">
    <link rel="stylesheet" href="<?=base_url('include/css/owl.carousel.css" type="text/css');?>">
    <link rel="stylesheet" href="<?=base_url('include/css/owl.theme.css" type="text/css');?>">
    <link rel="stylesheet" href="<?=base_url('include/css/owl.transitions.css" type="text/css');?>">
    <link rel="stylesheet" href="<?=base_url('include/css/magnific-popup.css" type="text/css');?>">
    <link rel="stylesheet" href="<?=base_url('include/css/jquery.countdown.css" type="text/css');?>">
    <link rel="stylesheet" href="<?=base_url('include/css/style.css" type="text/css');?>">
    <link rel="stylesheet" href="<?=base_url('include/css/colors/red.css" type="text/css');?>">
</head>

<body>

    <div id="wrapper">

        <div class="page-overlay">
            <div class="preloader-wrap">
                <div class="spinner">
                    <div class="bounce1"></div>
                    <div class="bounce2"></div>
                    <div class="bounce3"></div>
                </div>
            </div>
        </div>

        <!-- header begin -->
     <?php include "header.php";?>
        <!-- header close -->

        <!-- content begin -->
        <div id="content" class="no-bottom no-top">
            <div id="top"></div>

            <!-- section begin -->
            <section id="subheader" class="text-light" data-bgimage="url(images/background/14.jpg)" data-stellar-background-ratio=".2">
                <div class="overlay-bg t50">

                    <div class="container">
                        <div class="row">
                            <div class="col-md-12">
                                <h1>Contact Us</h1>
                                <p>Get in touch with us</p>
                            </div>
                        </div>
                    </div>

                </div>

            </section>
            <!-- section close -->

            <!-- section begin -->
            <section id="section-contact" data-bgcolor="#f9f9f9">
                <div class="container">
                    <div class="row">

                        <div class="col-md-8 mb-md-30">
                            <form name="contactForm" id='contact_form' class="de_form" method="post" action='https://www.designesia.com/themes/bolo/email.php'>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="field-set">
                                            <input type='text' name='name' id='name' class="form-control" placeholder="Your Name">
                                            <div class="line-fx"></div>
                                        </div>

                                        <div class="field-set">
                                            <input type='text' name='email' id='email' class="form-control" placeholder="Your Email">
                                            <div class="line-fx"></div>
                                        </div>

                                        <div class="field-set">
                                            <input type='text' name='phone' id='phone' class="form-control" placeholder="Your Phone">
                                            <div class="line-fx"></div>
                                        </div>
                                    </div>

                                    <div class="col-md-6">
                                        <div class="field-set">
                                            <textarea name='message' id='message' class="form-control" placeholder="Your Message"></textarea>
                                            <div class="line-fx"></div>
                                        </div>
                                    </div>

                                    <div class="col-md-12">
                                        <div id='submit'>
                                            <input type='submit' id='send_message' value='Submit Form' class="btn btn-custom color-2">
                                        </div>
                                        <div id='mail_success' class='success'>Your message has been sent successfully.</div>
                                        <div id='mail_fail' class='error'>Sorry, error occured this time sending your message.</div>
                                    </div>


                                </div>
                            </form>

                        </div>

                        <div class="col-md-4">
                            <h6 class="id-color">Call Us</h6>
                            (208) 333 9296
                            <div class="spacer-single"></div>
                            <h6 class="id-color">Address</h6>
                            Collins Street West, London, UK
                            <div class="spacer-single"></div>
                            <h6 class="id-color">Email Us</h6>
                            contact@bolostudio.com
                        </div>

                    </div>

                </div>
            </section>
            <!-- section close -->

        </div>
        <!-- content close -->

        <!-- footer begin -->
       <?php include "footer.php";?>
        <!-- footer close -->

        <a href="#" id="back-to-top"></a>

        <div id="preloader">
            <div class="preloader1"></div>
        </div>

    </div>

    <!-- Javascript Files
    ================================================== -->
    <script src="<?=base_url('include/js/jquery.min.js');?>"></script>
        <script src="<?=base_url('include/js/bootstrap.min.js');?>"></script>
        <script src="<?=base_url('include/js/jquery.isotope.min.js');?>"></script>
        <script src="<?=base_url('include/js/easing.js');?>"></script>
        <script src="<?=base_url('include/js/owl.carousel.js');?>"></script>
        <script src="<?=base_url('include/js/jquery.countTo.js');?>"></script>
        <script src="<?=base_url('include/js/wow.min.js');?>"></script>
        <script src="<?=base_url('include/js/jquery.magnific-popup.min.js');?>"></script>
        <script src="<?=base_url('include/js/enquire.min.js');?>"></script>
        <script src="<?=base_url('include/js/jquery.stellar.min.js');?>"></script>
        <script src="<?=base_url('include/js/jquery.plugin.js');?>"></script>     
        <script src="<?=base_url('include/js/jquery.easeScroll.js');?>"></script>
        <script src="<?=base_url('include/js/designesia.js');?>"></script>
        <script src="<?=base_url('include/js/validation.js');?>"></script>

</body>


<!-- Mirrored from www.designesia.com/themes/bolo/contact.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 06 Nov 2020 07:05:03 GMT -->
</html>