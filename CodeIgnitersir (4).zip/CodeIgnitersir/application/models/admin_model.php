<?php
class admin_model extends CI_model
{

	function saverecords($username,$password)
	{
			$q=$this->db->where(['User_Name'=>$username,'Password'=>$password])
				->get('login');
		if($q->num_rows() > 0){
			return true;
		}
		else{
			return false;
		}
}


	function getAllUsers(){
		$response=$this->db->get('login');
		//fetch user data//
		$data=$response->result_array();
		return $data;
	}
}

?>