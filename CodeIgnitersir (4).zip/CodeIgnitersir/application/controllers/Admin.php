<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {
	 public function __construct()
	 {

	 	parent::__construct();
	 	 $this->load->library('session');
		
	// 	if($this->session->set_userdata('Admin'))
	// 		redirect('Admin/welcome');
	// 	if(!$this->session->Userdata('Admin'))
	// 		redirect('Admin');
	}

	public function index()
	{
		$this->load->view('Admin/login');	
	}

	// public function__construct()
	// {

	// 	parent::__construct();
	// }
	// public function registration(){
	// 	if($this->input->post('register')){

	// 		$u=$this->input->post('Username');
	// 		$e=$this->input->post('Email Address ');
	// 		$p=$this->input->post('Password ');
	// 		$que=$this->db->query("insert into index values('','$u','$e','$p')");
	// 		redirect('Admin/login');
	// 	}
		
	// 	$this->load->view('Admin/register');	
	// }

	//for login //
	public function login(){
	if(isset($_POST['submit'])){
	       $username=$this->input->post('username');
		   $password=$this->input->post('password');
			$this->load->model('admin_model');
			$result = $this->admin_model->saverecords($username,$password);
			if($result)
			{
				$this->session->set_userdata('username',$username);
				return redirect('admin/welcome');
			}else{
				echo"sry";
			}
	}else{
		echo "Not submitted";
	}
}
public function welcome(){
	if($this->session->userdata('username')){
		$this->load->view('admin/dashboard');
 }
}


public function logout(){
	$this->session->sess_destroy('username');
	 return redirect('admin/index');
}




}
?>